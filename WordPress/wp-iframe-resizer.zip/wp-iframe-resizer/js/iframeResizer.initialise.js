jQuery(function($) {
  $('iframe.cross-domain-resizer').iFrameResize({
    checkOrigin: false
  });
});

